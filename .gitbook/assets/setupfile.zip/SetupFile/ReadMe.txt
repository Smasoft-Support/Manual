請執行Setup.bat檔即可。

Please execute "Setup.bat" file.